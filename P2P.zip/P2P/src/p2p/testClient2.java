package p2p;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class testClient2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int serverPort;
		String host="localhost";
		String type;
		String downloadPath="/media/lucas/WD 2T/共用文件/文档/学习/COMP208 Group Soft"
				+ "ware  Project/test/download.txt";
		String filePath="/media/lucas/WD 2T/共用文件/文档/学习/COMP208 Group Soft"
				+ "ware  Project/test/file.txt";
		String outputPath="/media/lucas/WD 2T/共用文件/文档/学习/COMP208 Group Soft"
				+ "ware  Project/test/outputClient2.txt";
//		FileInputStream fis;
//		try {
//			fis =new FileInputStream("/media/lucas/WD 2T/共用文件/文档/学习/COMP208 Group Software  "
//					+ "Project/test/inputClient.txt");
//			System.setIn(fis);
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
//		PrintStream ps;
//		try {
//			ps = new PrintStream(new FileOutputStream(outputPath));
//			System.setOut(ps);
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
		Scanner kb=new Scanner(System.in);
		while(true) {
			
			try {
				System.out.println("Please input the host type, q to quit:");
				type=kb.nextLine();
				if(type.equalsIgnoreCase("q")) {
					break;
				}else if(type.equalsIgnoreCase("server")) {
					
					ServerSocket welcomeSocket=new ServerSocket(8888);
					Socket serverSocket=welcomeSocket.accept();
					MainThread server=new MainThread(1,8000);
					
				}else {
					MainThread client = new MainThread(2,9001);
					Thread t=new Thread(client);
					t.start();
					t.join();
				}
				
			}catch(IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}

}
