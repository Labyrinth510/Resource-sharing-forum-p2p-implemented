package p2p;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MainThread implements Runnable {

	private HashMap<Integer, FileThread> fileThreads = new HashMap<Integer, FileThread>();
	private ThreadPoolExecutor executor; // thread pool of the download
	private ArrayList<Future<?>> currentFutures = new ArrayList<Future<?>>();

	private ServerSocket welcomeSocket;
	private int port;
	private String hostName = "localhost";
	private int ID;
	private RequestHandler requestHandler;
	private int threadMaxNum = 10;
	private int threadBufferMaxNum = 20;

	private long toalUploads;
	private long totalDownloads;

	public MainThread(int ID, int port) {
		// TODO Auto-generated method stub
		try {
			this.ID = ID;
			this.port = port;
			this.toalUploads = 0;
			this.totalDownloads = 0;
			welcomeSocket = new ServerSocket(port);
			this.requestHandler = new RequestHandler(this);
			// initialize the thread pool
			executor = new ThreadPoolExecutor(threadMaxNum, threadBufferMaxNum, 0L, TimeUnit.MILLISECONDS,
					new LinkedBlockingQueue<Runnable>());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void run() {
		Scanner kb = new Scanner(System.in);
		System.out.println("Run MainThread, ID: " + this.ID + ", Port number:" + this.port);
		Thread t = new Thread(new RequestHandler(this));
		t.start();
		int op;
		do {
			System.out.println("What do you want to do?");
			System.out.println("1.Start File\t2.Edit one file thread\n3.Close");
			op = kb.nextInt();
			kb.nextLine();
			System.out.println("Main thread read operation:" + op);
			switch (op) {
			case 1:
				newFileThread();
				break;
			case 2:
				System.out.println("Input the file thread ID:");
				int id = kb.nextInt();
				FileThread fileThread = fileThreads.get(id);
				System.out.println("What do you want to do?");
				System.out.println("1.Start Thread\t2.Add a member\n3.Close");
				int operation = kb.nextInt();
				kb.nextLine();
				switch (operation) {
				case 1:
					try {
						Future<?> future = executor.submit(fileThread);
						currentFutures.add(future);
						System.out.println("Download pool submit a subThread");
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 2:
					System.out.println("Input the member hostname:");
					String hostname = kb.nextLine();
					System.out.println("Input the member port number:");
					int portNumber = kb.nextInt();
					kb.nextLine();
					fileThread.addMember(hostname, portNumber);
					break;
				case 3:
					
					break;
				}
				break;
			case 3:

			}

		} while (op != 3);

	}

	public void newFileThread() {
		Scanner kb = new Scanner(System.in);
		int fileID;
		System.out.println("Please input the file ID:");
		fileID = kb.nextInt();
		kb.nextLine();

		String path = "/media/lucas/WD 2T/共用文件/文档/学习/COMP208 Group Software  Project/test/";
		System.out.println("Please input the file name:");
		path += kb.nextLine();

		System.out.println("Please input the file size:");
		long fileSize = kb.nextInt();
		kb.nextLine();
		FileThread fileThread = new FileThread(fileID, path, fileSize, this);
		fileThreads.put(fileID, fileThread);
		// fileThreads.put(fileID, fileThread);

	}

	public void setThreadMaxNum(int num) {
		this.threadMaxNum=num;
		this.threadBufferMaxNum=num+10;
		this.executor.setMaximumPoolSize(this.threadBufferMaxNum);
		this.executor.setCorePoolSize(this.threadMaxNum);
	}
	
	public void addTotalUploadsBy(long num) {
		this.toalUploads+=num;
	}
	
	public void addTotalDownloadsBy(long num) {
		this.totalDownloads+=num;
	}

	public FileThread getFileThread(int fileID) {
		return fileThreads.get(fileID);
	}

	public ServerSocket getWelcomeSocket() {
		return this.welcomeSocket;
	}

	public int getID() {
		return this.ID;
	}

	public String getHostName() {
		return this.hostName;
	}

	public int getPortNumber() {
		return this.port;
	}
	
	public long getTotalUploads() {
		return this.toalUploads;
	}
	
	public long getTotalDownloads() {
		return this.totalDownloads;
	}
}
