package p2p;

public class ConnectionEventObject extends java.util.EventObject {
	

	public ConnectionEventObject(Object source) {
		super(source);
	}
	
	public ConnectionEventObject(RequestHandler requestHandler) {
		super(requestHandler);
	}
	
	public RequestHandler getRequestHandler() {
		return (RequestHandler)super.getSource();
	}
}
