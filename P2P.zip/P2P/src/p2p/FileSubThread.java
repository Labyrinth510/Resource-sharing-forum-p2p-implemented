package p2p;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;

public class FileSubThread implements Runnable {
	private FileThread parentFileThread;
	private int fileID;
	private File file;
	private boolean isInitial;
	private Socket socket;
	private BitSet chunkList;
	private BitSet counterChunkList;
	private int chunkNum;
	private final static int chunkSize = 1024 * 1024; // 1MB one chunk
	private final static int bufferSize = 1024;
	private RandomAccessFile raf;
	private ObjectOutputStream dos;
	private ObjectInputStream dis;
	private final static String readEnding = "EOC";
	private final static byte[] readEndingByte = readEnding.getBytes();

	public FileSubThread(Socket socket, FileThread parentFileThread) {
		this.socket = socket;
		this.parentFileThread = parentFileThread;
		this.chunkList = parentFileThread.getChunkList();
		this.chunkNum = parentFileThread.getChunkNum();
		this.fileID = parentFileThread.getFileID();
		this.file = parentFileThread.getFile();
	}

	@Override
	public void run() {

		System.out.println("\n\nFileSubThread of fileThread " + parentFileThread.getFileID() + " of mainThread "
				+ parentFileThread.getMainThread().getID() + " is running");
		System.out.println("SubThread: " + Thread.currentThread().getName() + " is started");

		// apply the thread pool of fileThread to kill the subThread

		if (isInitial) {
			// PrintWriter output;

			System.out.println("This is the download side");
			try {
				raf = new RandomAccessFile(file, "rw");
				System.out.println("raf created");
				dos = new ObjectOutputStream(socket.getOutputStream());
				System.out.println("dos created");
//				output = new PrintWriter(socket.getOutputStream(), true);
//				output.println("download");
//				output.println(fileID);

				// this message is used to request for file
				Message requestFile = new Message(Message.requestFile);
				System.out.println("Message created");
				requestFile.setFileID(fileID);
				System.out.println("file ID  set");
				dos.writeObject(requestFile);
				dos.flush();
				System.out.println("Send Message:\n"+requestFile.toString());
				
				dis = new ObjectInputStream(socket.getInputStream());
				System.out.println("dis created");
				for (int i = 0; i < chunkNum && !Thread.currentThread().isInterrupted(); i++) {

					if (!chunkList.get(i) && counterChunkList.get(i)) {

						System.out.println("\nCurrent Thread: " + Thread.currentThread().getName() + "\ni: " + i
								+ ", chunkList:" + chunkList + "\nThe server has lack chunk " + i);
						int offset = i * chunkSize;
//						output.println(offset);

						// message to request for offset of file
						Message requestChunk = new Message(Message.requestChunk);
						requestChunk.setOffset(offset);
						dos.writeObject(requestChunk);
						dos.flush();
						System.out.println("Send Message:\n"+requestChunk.toString()+"\n");
						
						receiveFile(offset);
						chunkList.set(i);
						parentFileThread.downloadsAddBy(chunkSize);
						parentFileThread.getMainThread().addTotalDownloadsBy(chunkSize);
						System.out.println(
								"SubThread" + Thread.currentThread().getName() + " chunk " + i + " is downloaded\n");
					}
				}

				// message to terminate this subThread
				Message termination = new Message(Message.termination);
				dos.writeObject(termination);
				dos.flush();
				System.out.println("Send Message:\n"+termination.toString());
//				output.println("$#Terminated#$");
				dos.close();
				dis.close();
				raf.close();
				System.out.println("subThread" + Thread.currentThread().getName()
						+ " no more chunk or cancelled, download FileSubThread ends");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			System.out.println("This is the upload side");
			try {
				raf = new RandomAccessFile(file, "r");
				dos = new ObjectOutputStream(socket.getOutputStream());
				System.out.println("dos created");
				// BufferedReader input = new BufferedReader(new
				// InputStreamReader(socket.getInputStream()));
//				dis = new ObjectInputStream(socket.getInputStream());
//				System.out.println("dis created");

				while (!Thread.currentThread().isInterrupted()) {
//					String inputs = input.readLine();
//					System.out.println("input:" + inputs);
//					if (inputs.equals("$#Terminated#$"))
//						break;
//					int offset = Integer.parseInt(inputs);
					// System.out.println("Receive request chunk for fileID:" + fileID + " offset:"
					// + offset);
////					input.close();
//					sendFile(offset);
					try {
						Message input = (Message) dis.readObject();
						System.out.println("Receive Message:\n"+input.toString()+"\n");
						if (input.getType() == Message.termination)
							break;
						if (input.isValid() && input.getType() == Message.requestChunk) {
							int offset = input.getOffset();
							sendFile(offset);
							parentFileThread.uploadsAddBy(chunkSize);
							parentFileThread.getMainThread().addTotalUploadsBy(chunkSize);
						}
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				raf.close();
				dos.close();
				dis.close();
				System.out.println("finish upload, upload FileSubThread ends");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public void sendFile(int offset) {

		while (true) {
			try {
				byte[] buffer = new byte[bufferSize];
				int totalRead = 0, readLen;
				raf.seek(offset);
				boolean endChunk=false;
				while(true) {
					if(chunkSize-totalRead<=bufferSize) {
						readLen = raf.read(buffer, 0, chunkSize - totalRead);
						endChunk=true;
					}else {
						readLen = raf.read(buffer, 0, bufferSize);
					}
					
					totalRead+=readLen;
					//System.out.println("chunkSize: "+chunkSize+" total read:"+totalRead);
					Message sendMessage = new Message(Message.sendPiece);
					sendMessage.setSendPiece(true, buffer, readLen, false);
					dos.writeObject(sendMessage);
					dos.flush();
					//System.out.println("Send Message:\n"+sendMessage.toString());
					
					if(endChunk) {
						System.out.println("end of chunk");
						break;
					}
				}
				
//				while (totalRead < chunkSize
//						&& (readLen = raf.read(buffer, 0, Math.min(bufferSize, chunkSize - totalRead))) > 0) {
//					totalRead += readLen;
//					Message sendMessage = new Message(Message.sendPiece);
//					sendMessage.setSendPiece(true, buffer, readLen, false);
//					dos.writeObject(sendMessage);
//					dos.flush();
//					System.out.println("Send Message:\n"+sendMessage.toString());
//
////					dos.write(buffer, 0, readLen);
////					dos.flush();
//				}
				Message sendChunkEnd = new Message(Message.sendPiece);
				sendChunkEnd.setSendPiece(true, null, 0, true);
				dos.writeObject(sendChunkEnd);
				dos.flush();
				System.out.println("Send Message:\n"+sendChunkEnd.toString());

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
	}

	public void receiveFile(int offset) {
		try {

			raf.seek(offset);
//			byte[] buffer = new byte[bufferSize];
//			int readLen = 0;
			while (true) {
				try {
					Message receiveMessage = (Message) dis.readObject();
					//System.out.println("SubThread: " + Thread.currentThread().getName() + " Receive Message:\n"+receiveMessage.toString());
					if (receiveMessage.isValid() && receiveMessage.getType() == Message.sendPiece) {
						if (receiveMessage.getIsEndChunk()) {
							break;
						} else {
							raf.write(receiveMessage.getUploads(), 0, receiveMessage.getUploadLen());
						}
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

//			while ((readLen = dis.read(buffer, 0, buffer.length)) != -1) {
//
//				// System.out.println("SubThread: " + Thread.currentThread().getName() + ",
//				// offset:" + offset + "\nreads:"
//				// + (new String(buffer)));
//
//				// !!! use byte to compare
//				if (readEnd(buffer, readLen)) {
//					raf.write(buffer, 0, readLen - readEndingByte.length);
//					break;
//				}
//
//				raf.write(buffer, 0, readLen);
//			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean readEnd(byte[] buffer, int readLen) {
		if (readLen < readEndingByte.length)
			return false;

		for (int i = 0; i < readEndingByte.length; i++) {
			if (buffer[readLen - 1 - i] != readEndingByte[readEndingByte.length - 1 - i])
				return false;
		}
		return true;
	}

	public void setIsInitial(boolean value) {
		this.isInitial = value;
	}

	public void setCounterChunkList(BitSet counterChunkList) {
		this.counterChunkList = counterChunkList;
	}

	public void setInputStream(ObjectInputStream dis) {
		this.dis = dis;
		System.out.println("dis is set");
	}
}
