//package p2p;
//
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.io.RandomAccessFile;
//
//public class FileHandler {
//	private File filePath;
//	private int fileSize;
//	
//	public FileHandler(String filePath, int fileSize) {
//		this.filePath=new File(filePath);
//		this.fileSize=fileSize;
//		
//		if(this.filePath.exists()) {
//			try {
//				RandomAccessFile raf=new RandomAccessFile(this.filePath,"rw");
//				raf.setLength(fileSize);
//				raf.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
//		}else {
//			
//		}
//	}
//	public File getFilePath() {
//		return this.filePath;
//	}
//}
