package p2p;

import java.net.Socket;

public interface ConnectionListener extends java.util.EventListener{
	
	public void update(ConnectionEventObject o, Socket acceptSocket);
}
